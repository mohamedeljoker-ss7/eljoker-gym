# ElJoker Gym (Free Edition)
مشروع Next.js بسيط بدون أي عمليات دفع أو قواعد بيانات.
يحتوي على صفحات عربية كاملة وأداة لحساب BMI.
## التشغيل
npm install
npm run dev
ثم افتح http://localhost:3000
## النشر
ارفع المشروع إلى GitHub واربطه بـ Vercel.
