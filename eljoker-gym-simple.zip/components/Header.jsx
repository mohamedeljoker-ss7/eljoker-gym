import Link from 'next/link'
export default function Header(){
  return (
    <header className="site-header">
      <div className="container" dir="rtl">
        <h1 className="brand">ElJoker Gym</h1>
        <nav>
          <Link href="/">الرئيسية</Link>
          <Link href="/tools">الأدوات</Link>
          <Link href="/mydata">بياناتي</Link>
          <Link href="/exercises">تمارين</Link>
          <Link href="/about">عن ElJoker Gym</Link>
          <Link href="/contact">اتصل بنا</Link>
        </nav>
      </div>
    </header>
  )
}
