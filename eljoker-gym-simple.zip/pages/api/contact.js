import fs from 'fs'
import path from 'path'
export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).end()
  const {name,email,message}=req.body
  if(!name||!email||!message) return res.status(400).json({success:false})
  const dataDir = path.join(process.cwd(),'data')
  if(!fs.existsSync(dataDir)) fs.mkdirSync(dataDir)
  const file = path.join(dataDir,'messages.json')
  let messages = []
  try{ messages = JSON.parse(fs.existsSync(file)? fs.readFileSync(file): '[]') }
  catch(e){ messages = [] }
  messages.push({id:Date.now(), name,email,message,created_at:new Date().toISOString()})
  fs.writeFileSync(file, JSON.stringify(messages,null,2))
  res.json({success:true})
}
