import Header from '../components/Header'
import {useState} from 'react'
export default function Contact(){
  const [name,setName]=useState('')
  const [email,setEmail]=useState('')
  const [msg,setMsg]=useState('')
  const [ok,setOk]=useState(null)
  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/contact', {
      method:'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({name,email,message:msg})
    })
    const data = await res.json()
    setOk(data.success)
  }
  return (
    <div dir="rtl">
      <Header />
      <main className="container">
        <h2>اتصل بنا</h2>
        <form onSubmit={submit}>
          <label>الاسم<input value={name} onChange={e=>setName(e.target.value)} /></label>
          <label>البريد<input value={email} onChange={e=>setEmail(e.target.value)} /></label>
          <label>الرسالة<textarea value={msg} onChange={e=>setMsg(e.target.value)} /></label>
          <button type="submit">إرسال</button>
        </form>
        {ok && <p>تم الإرسال، شكراً لك!</p>}
      </main>
    </div>
  )
}
