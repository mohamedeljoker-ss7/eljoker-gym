import Header from '../components/Header'
export default function Home(){
  return (
    <div dir="rtl">
      <Header />
      <main className="container">
        <h2>أهلاً بك في ElJoker Gym</h2>
        <section>
          <h3>الأدوات</h3>
          <ul><li><a href="/tools/bmi">مؤشر كتلة الجسم (BMI)</a></li></ul>
        </section>
        <section><h3>عن الموقع</h3><p>منصة مجانية لمتابعة لياقتك.</p></section>
        <footer>© 2026 ElJoker Gym</footer>
      </main>
    </div>
  )
}
