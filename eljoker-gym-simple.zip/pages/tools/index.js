import Header from '../../components/Header'
import Link from 'next/link'
export default function Tools(){
  return (
    <div dir="rtl">
      <Header />
      <main className="container">
        <h2>الأدوات</h2>
        <ul><li><Link href="/tools/bmi">مؤشر كتلة الجسم (BMI)</Link></li></ul>
      </main>
    </div>
  )
}
