import Header from '../../components/Header'
import { useState } from 'react'
export default function BMI(){
  const [weight,setWeight]=useState('')
  const [height,setHeight]=useState('')
  const [result,setResult]=useState(null)
  function calc(e){
    e.preventDefault()
    const w=parseFloat(weight)
    const h=parseFloat(height)/100
    if(!w||!h) return
    const bmi=(w/(h*h)).toFixed(1)
    setResult(bmi)
  }
  return (
    <div dir="rtl">
      <Header />
      <main className="container">
        <h2>مؤشر كتلة الجسم (BMI)</h2>
        <form onSubmit={calc}>
          <label>الوزن (كجم)<input value={weight} onChange={e=>setWeight(e.target.value)} /></label>
          <label>الطول (سم)<input value={height} onChange={e=>setHeight(e.target.value)} /></label>
          <button type="submit">احسب</button>
        </form>
        {result && <p>نتيجتك: {result}</p>}
      </main>
    </div>
  )
}
